import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { registerAudioRoutes } from "./replit_integrations/audio";
import { openai } from "./replit_integrations/audio/client"; // Use OpenAI client from integration

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register Integration Routes
  registerChatRoutes(app);
  registerImageRoutes(app);
  registerAudioRoutes(app);

  // === AUTH (Simple Mock Auth) ===
  app.post(api.auth.login.path, async (req, res) => {
    const { username, password } = req.body;
    const user = await storage.getUserByUsername(username);
    if (!user || user.password !== password) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    // Simple session/cookie would be better, but for MVP we might just return the user
    // and frontend stores it in localStorage or context.
    // Ideally we use a session middleware.
    (req as any).session.userId = user.id;
    res.json(user);
  });

  app.post(api.auth.logout.path, (req, res) => {
    (req as any).session.destroy();
    res.sendStatus(200);
  });

  app.get(api.auth.me.path, async (req, res) => {
    if (!(req as any).session.userId) return res.status(401).json(null);
    const user = await storage.getUser((req as any).session.userId);
    res.json(user || null);
  });

  // === USERS ===
  app.get(api.users.list.path, async (req, res) => {
    const users = await storage.getUsers(req.query.role as string, Number(req.query.departmentId));
    res.json(users);
  });

  app.post(api.users.create.path, async (req, res) => {
    try {
      const input = api.users.create.input.parse(req.body);
      const user = await storage.createUser(input);
      await storage.createAuditLog({
        action: "CREATE_USER",
        userId: (req as any).session.userId, // Creator
        details: `Created user ${user.username} as ${user.role}`
      });
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json(err);
      res.status(500).json({ message: "Internal Error" });
    }
  });

  // === DEPARTMENTS ===
  app.get(api.departments.list.path, async (req, res) => {
    const depts = await storage.getDepartments();
    res.json(depts);
  });
  
  app.get(api.departments.get.path, async (req, res) => {
      const dept = await storage.getDepartment(Number(req.params.id));
      if (!dept) return res.status(404).json({ message: "Department not found" });
      res.json(dept);
  });

  app.post(api.departments.create.path, async (req, res) => {
    const input = api.departments.create.input.parse(req.body);
    const dept = await storage.createDepartment(input);
    res.status(201).json(dept);
  });

  // === SUBJECTS ===
  app.get(api.subjects.list.path, async (req, res) => {
    const subs = await storage.getSubjects(Number(req.query.departmentId));
    res.json(subs);
  });

  app.post(api.subjects.create.path, async (req, res) => {
    const input = api.subjects.create.input.parse(req.body);
    const sub = await storage.createSubject(input);
    res.status(201).json(sub);
  });

  // === TIMETABLES (AI) ===
  app.get(api.timetables.list.path, async (req, res) => {
    const tts = await storage.getTimetables(Number(req.query.departmentId));
    res.json(tts);
  });

  app.post(api.timetables.generate.path, async (req, res) => {
    try {
      const { departmentId, mode, constraints } = req.body;
      
      // Get necessary data for AI
      const dept = await storage.getDepartment(departmentId);
      const staff = await storage.getUsers('staff', departmentId);
      const subjects = await storage.getSubjects(departmentId);

      // AI Generation Logic
      let prompt = `Generate a weekly college timetable JSON structure for Department: ${dept?.name}.
      Days: Mon-Fri. Periods: 1-6.
      Subjects: ${subjects.map(s => s.name).join(', ')}.
      Staff: ${staff.map(s => s.name).join(', ')}.
      Format: Array of objects { day: string, periods: Array<{ period: number, subject: string, staff: string }> }.
      Ensure balanced workload.`;

      if (mode === 'assisted' && constraints) {
        prompt += ` Constraints: ${JSON.stringify(constraints)}`;
      }

      // Call OpenAI
      const response = await (openai as any).chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const generatedData = JSON.parse(response.choices[0]?.message?.content || "{}");

      const timetable = await storage.createTimetable({
        departmentId,
        data: generatedData,
        status: 'draft',
        createdBy: (req as any).session.userId || 1 // Fallback to 1 if no session for now
      });

      await storage.createAuditLog({
        action: "GENERATE_TIMETABLE",
        userId: (req as any).session.userId,
        details: `Generated timetable for ${dept?.name} in ${mode} mode`
      });

      res.json(timetable);
    } catch (e) {
      console.error(e);
      res.status(500).json({ message: "Failed to generate timetable" });
    }
  });

  app.patch(api.timetables.publish.path, async (req, res) => {
      const t = await storage.updateTimetableStatus(Number(req.params.id), 'published');
      res.json(t);
  });

  // === LEAVES ===
  app.get(api.leaves.list.path, async (req, res) => {
    const l = await storage.getLeaves(req.query.status as string);
    res.json(l);
  });

  app.post(api.leaves.create.path, async (req, res) => {
    const input = api.leaves.create.input.parse(req.body);
    const l = await storage.createLeave(input);
    res.status(201).json(l);
  });

  app.patch(api.leaves.updateStatus.path, async (req, res) => {
    const { status, rejectionReason } = req.body;
    const l = await storage.updateLeaveStatus(Number(req.params.id), status, rejectionReason);
    res.json(l);
  });

  // === FINANCE ===
  app.get(api.finance.list.path, async (req, res) => {
    const f = await storage.getFinanceRequests();
    res.json(f);
  });

  app.post(api.finance.create.path, async (req, res) => {
    const input = api.finance.create.input.parse(req.body);
    const f = await storage.createFinanceRequest(input);
    res.status(201).json(f);
  });
  
  app.patch(api.finance.updateStatus.path, async (req, res) => {
      const f = await storage.updateFinanceStatus(Number(req.params.id), req.body.status);
      res.json(f);
  });

  // === NOTICES ===
  app.get(api.notices.list.path, async (req, res) => {
    const n = await storage.getNotices();
    res.json(n);
  });

  app.post(api.notices.create.path, async (req, res) => {
    const input = api.notices.create.input.parse(req.body);
    const n = await storage.createNotice(input);
    res.status(201).json(n);
  });

  // === MARKS ===
  app.get(api.marks.list.path, async (req, res) => {
    const m = await storage.getStudentMarks(req.query.studentId as string);
    res.json(m);
  });

  app.post(api.marks.create.path, async (req, res) => {
    const input = api.marks.create.input.parse(req.body);
    const m = await storage.createStudentMark(input);
    res.status(201).json(m);
  });
  
  // === STATS ===
  app.get(api.stats.get.path, async (req, res) => {
      // Simple mock stats for dashboard
      res.json({
          totalStudents: 1200,
          totalStaff: 85,
          activeNotices: 5,
          pendingLeaves: 3
      });
  });

  // === SEEDING ===
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const admin = await storage.getUserByUsername("admin");
  if (!admin) {
    await storage.createUser({
      username: "admin",
      password: "Admin@123", // In a real app, hash this!
      role: "admin",
      name: "System Admin"
    });
    console.log("Seeded Admin user");
  }
}
