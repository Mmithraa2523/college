import { db } from "./db";
import {
  users, departments, subjects, timetables, leaves, financeRequests, notices, studentMarks, auditLogs,
  type User, type InsertUser, type Department, type Subject, type Timetable, type Leave, type FinanceRequest, type Notice, type StudentMark, type AuditLog
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { chatStorage } from "./replit_integrations/chat/storage";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(role?: string, departmentId?: number): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;

  // Departments
  getDepartments(): Promise<Department[]>;
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(dept: any): Promise<Department>;

  // Subjects
  getSubjects(departmentId?: number): Promise<Subject[]>;
  createSubject(subject: any): Promise<Subject>;

  // Timetables
  getTimetables(departmentId?: number): Promise<Timetable[]>;
  createTimetable(timetable: any): Promise<Timetable>;
  updateTimetableStatus(id: number, status: string): Promise<Timetable>;

  // Leaves
  getLeaves(status?: string): Promise<Leave[]>;
  createLeave(leave: any): Promise<Leave>;
  updateLeaveStatus(id: number, status: string, rejectionReason?: string): Promise<Leave>;

  // Finance
  getFinanceRequests(): Promise<FinanceRequest[]>;
  createFinanceRequest(req: any): Promise<FinanceRequest>;
  updateFinanceStatus(id: number, status: string): Promise<FinanceRequest>;

  // Notices
  getNotices(): Promise<Notice[]>;
  createNotice(notice: any): Promise<Notice>;

  // Marks
  getStudentMarks(studentId?: string): Promise<StudentMark[]>;
  createStudentMark(mark: any): Promise<StudentMark>;

  // Audit
  createAuditLog(log: any): Promise<AuditLog>;
  
  // Chat
  chat: typeof chatStorage;
}

export class DatabaseStorage implements IStorage {
  chat = chatStorage;

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUsers(role?: string, departmentId?: number): Promise<User[]> {
    let query = db.select().from(users);
    if (role) query = query.where(eq(users.role, role)) as any;
    if (departmentId) query = query.where(eq(users.departmentId, departmentId)) as any;
    return await query;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Departments
  async getDepartments(): Promise<Department[]> {
    return await db.select().from(departments);
  }
  
  async getDepartment(id: number): Promise<Department | undefined> {
      const [dept] = await db.select().from(departments).where(eq(departments.id, id));
      return dept;
  }

  async createDepartment(dept: any): Promise<Department> {
    const [d] = await db.insert(departments).values(dept).returning();
    return d;
  }

  // Subjects
  async getSubjects(departmentId?: number): Promise<Subject[]> {
    let query = db.select().from(subjects);
    if (departmentId) query = query.where(eq(subjects.departmentId, departmentId)) as any;
    return await query;
  }

  async createSubject(subject: any): Promise<Subject> {
    const [s] = await db.insert(subjects).values(subject).returning();
    return s;
  }

  // Timetables
  async getTimetables(departmentId?: number): Promise<Timetable[]> {
    let query = db.select().from(timetables).orderBy(desc(timetables.createdAt));
    if (departmentId) query = query.where(eq(timetables.departmentId, departmentId)) as any;
    return await query;
  }

  async createTimetable(timetable: any): Promise<Timetable> {
    const [t] = await db.insert(timetables).values(timetable).returning();
    return t;
  }
  
  async updateTimetableStatus(id: number, status: string): Promise<Timetable> {
      const [t] = await db.update(timetables).set({ status }).where(eq(timetables.id, id)).returning();
      return t;
  }

  // Leaves
  async getLeaves(status?: string): Promise<Leave[]> {
    let query = db.select().from(leaves).orderBy(desc(leaves.createdAt));
    if (status) query = query.where(eq(leaves.status, status)) as any;
    return await query;
  }

  async createLeave(leave: any): Promise<Leave> {
    const [l] = await db.insert(leaves).values(leave).returning();
    return l;
  }

  async updateLeaveStatus(id: number, status: string, rejectionReason?: string): Promise<Leave> {
    const [l] = await db.update(leaves)
      .set({ status, rejectionReason })
      .where(eq(leaves.id, id))
      .returning();
    return l;
  }

  // Finance
  async getFinanceRequests(): Promise<FinanceRequest[]> {
    return await db.select().from(financeRequests).orderBy(desc(financeRequests.createdAt));
  }

  async createFinanceRequest(req: any): Promise<FinanceRequest> {
    const [r] = await db.insert(financeRequests).values(req).returning();
    return r;
  }

  async updateFinanceStatus(id: number, status: string): Promise<FinanceRequest> {
    const [r] = await db.update(financeRequests)
      .set({ status })
      .where(eq(financeRequests.id, id))
      .returning();
    return r;
  }

  // Notices
  async getNotices(): Promise<Notice[]> {
    return await db.select().from(notices).orderBy(desc(notices.createdAt));
  }

  async createNotice(notice: any): Promise<Notice> {
    const [n] = await db.insert(notices).values(notice).returning();
    return n;
  }

  // Marks
  async getStudentMarks(studentId?: string): Promise<StudentMark[]> {
    let query = db.select().from(studentMarks).orderBy(desc(studentMarks.createdAt));
    if (studentId) query = query.where(eq(studentMarks.studentId, studentId)) as any;
    return await query;
  }

  async createStudentMark(mark: any): Promise<StudentMark> {
    const [m] = await db.insert(studentMarks).values(mark).returning();
    return m;
  }
  
  // Audit
  async createAuditLog(log: any): Promise<AuditLog> {
      const [l] = await db.insert(auditLogs).values(log).returning();
      return l;
  }
}

export const storage = new DatabaseStorage();
