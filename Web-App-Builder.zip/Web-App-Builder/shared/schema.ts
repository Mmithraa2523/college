import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
export * from "./models/chat";

// === ENUMS ===
export const userRoles = ["admin", "hod", "staff", "office_admin", "principal"] as const;
export const leaveStatus = ["pending_hod", "pending_principal", "approved", "rejected"] as const;
export const financeStatus = ["pending", "approved", "rejected", "paid"] as const;
export const noticeType = ["broadcast", "department", "individual"] as const;
export const noticeTargetRole = ["all", "staff", "student"] as const; // Simplified for now

// === TABLES ===

export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  hodId: integer("hod_id"), // Will reference users.id, but circular dependency if defined here strictly in some ORMs, but Drizzle handles it.
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: userRoles }).notNull(),
  name: text("name").notNull(),
  departmentId: integer("department_id").references(() => departments.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  departmentId: integer("department_id").references(() => departments.id).notNull(),
});

export const timetables = pgTable("timetables", {
  id: serial("id").primaryKey(),
  departmentId: integer("department_id").references(() => departments.id).notNull(),
  data: jsonb("data").notNull(), // Stores the generated timetable structure
  status: text("status").default("draft"), // draft, published
  createdBy: integer("created_by").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const leaves = pgTable("leaves", {
  id: serial("id").primaryKey(),
  staffId: integer("staff_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // Sick, Casual, etc.
  reason: text("reason").notNull(),
  startDate: text("start_date").notNull(), // Store as ISO string for simplicity
  endDate: text("end_date").notNull(),
  status: text("status", { enum: leaveStatus }).default("pending_hod"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const financeRequests = pgTable("finance_requests", {
  id: serial("id").primaryKey(),
  requesterId: integer("requester_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // quotation, bill
  amount: integer("amount").notNull(),
  description: text("description").notNull(),
  status: text("status", { enum: financeStatus }).default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notices = pgTable("notices", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  authorId: integer("author_id").references(() => users.id).notNull(),
  type: text("type", { enum: noticeType }).notNull(),
  departmentId: integer("department_id").references(() => departments.id), // Nullable for broadcast
  createdAt: timestamp("created_at").defaultNow(),
});

export const studentMarks = pgTable("student_marks", {
  id: serial("id").primaryKey(),
  studentId: text("student_id").notNull(),
  subjectId: integer("subject_id").references(() => subjects.id).notNull(),
  marks: integer("marks").notNull(),
  staffId: integer("staff_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  action: text("action").notNull(),
  userId: integer("user_id").references(() => users.id),
  details: text("details"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// === RELATIONS ===

export const departmentsRelations = relations(departments, ({ one, many }) => ({
  hod: one(users, {
    fields: [departments.hodId],
    references: [users.id],
  }),
  staff: many(users),
  subjects: many(subjects),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  department: one(departments, {
    fields: [users.departmentId],
    references: [departments.id],
  }),
}));

export const timetablesRelations = relations(timetables, ({ one }) => ({
  department: one(departments, {
    fields: [timetables.departmentId],
    references: [departments.id],
  }),
  creator: one(users, {
    fields: [timetables.createdBy],
    references: [users.id],
  }),
}));

export const leavesRelations = relations(leaves, ({ one }) => ({
  staff: one(users, {
    fields: [leaves.staffId],
    references: [users.id],
  }),
}));

export const financeRequestsRelations = relations(financeRequests, ({ one }) => ({
  requester: one(users, {
    fields: [financeRequests.requesterId],
    references: [users.id],
  }),
}));

export const noticesRelations = relations(notices, ({ one }) => ({
  author: one(users, {
    fields: [notices.authorId],
    references: [users.id],
  }),
  department: one(departments, {
    fields: [notices.departmentId],
    references: [departments.id],
  }),
}));

export const studentMarksRelations = relations(studentMarks, ({ one }) => ({
  subject: one(subjects, {
    fields: [studentMarks.subjectId],
    references: [subjects.id],
  }),
  staff: one(users, {
    fields: [studentMarks.staffId],
    references: [users.id],
  }),
}));

// === SCHEMAS ===

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertDepartmentSchema = createInsertSchema(departments).omit({ id: true });
export const insertSubjectSchema = createInsertSchema(subjects).omit({ id: true });
export const insertTimetableSchema = createInsertSchema(timetables).omit({ id: true, createdAt: true });
export const insertLeaveSchema = createInsertSchema(leaves).omit({ id: true, createdAt: true, status: true, rejectionReason: true });
export const insertFinanceRequestSchema = createInsertSchema(financeRequests).omit({ id: true, createdAt: true, status: true });
export const insertNoticeSchema = createInsertSchema(notices).omit({ id: true, createdAt: true });
export const insertStudentMarksSchema = createInsertSchema(studentMarks).omit({ id: true, createdAt: true });

// === TYPES ===

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Department = typeof departments.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Timetable = typeof timetables.$inferSelect;
export type Leave = typeof leaves.$inferSelect;
export type FinanceRequest = typeof financeRequests.$inferSelect;
export type Notice = typeof notices.$inferSelect;
export type StudentMark = typeof studentMarks.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;

export type LoginRequest = { username: string; password: string };
