import { z } from 'zod';
import { 
  insertUserSchema, 
  insertDepartmentSchema, 
  insertSubjectSchema, 
  insertTimetableSchema, 
  insertLeaveSchema, 
  insertFinanceRequestSchema, 
  insertNoticeSchema, 
  insertStudentMarksSchema,
  users, departments, subjects, timetables, leaves, financeRequests, notices, studentMarks, auditLogs
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login',
      input: z.object({ username: z.string(), password: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.void(),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: z.null(),
      },
    },
  },
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users',
      input: z.object({ role: z.string().optional(), departmentId: z.coerce.number().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/users',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  departments: {
    list: {
      method: 'GET' as const,
      path: '/api/departments',
      responses: {
        200: z.array(z.custom<typeof departments.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/departments',
      input: insertDepartmentSchema,
      responses: {
        201: z.custom<typeof departments.$inferSelect>(),
      },
    },
    get: {
        method: 'GET' as const,
        path: '/api/departments/:id',
        responses: {
            200: z.custom<typeof departments.$inferSelect>(),
            404: errorSchemas.notFound,
        }
    }
  },
  subjects: {
    list: {
      method: 'GET' as const,
      path: '/api/subjects',
      input: z.object({ departmentId: z.coerce.number().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof subjects.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/subjects',
      input: insertSubjectSchema,
      responses: {
        201: z.custom<typeof subjects.$inferSelect>(),
      },
    },
  },
  timetables: {
    list: {
      method: 'GET' as const,
      path: '/api/timetables',
      input: z.object({ departmentId: z.coerce.number().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof timetables.$inferSelect>()),
      },
    },
    generate: {
      method: 'POST' as const,
      path: '/api/timetables/generate',
      input: z.object({
        departmentId: z.number(),
        mode: z.enum(['automatic', 'assisted']),
        constraints: z.any().optional(), // For assisted mode
      }),
      responses: {
        200: z.custom<typeof timetables.$inferSelect>(), // Returns the generated (draft) timetable
      },
    },
    publish: {
      method: 'PATCH' as const,
      path: '/api/timetables/:id/publish',
      responses: {
        200: z.custom<typeof timetables.$inferSelect>(),
      },
    },
  },
  leaves: {
    list: {
      method: 'GET' as const,
      path: '/api/leaves',
      input: z.object({ status: z.string().optional() }).optional(), // Filter by status/role logic in backend
      responses: {
        200: z.array(z.custom<typeof leaves.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/leaves',
      input: insertLeaveSchema,
      responses: {
        201: z.custom<typeof leaves.$inferSelect>(),
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/leaves/:id/status',
      input: z.object({ status: z.string(), rejectionReason: z.string().optional() }),
      responses: {
        200: z.custom<typeof leaves.$inferSelect>(),
      },
    },
  },
  finance: {
    list: {
      method: 'GET' as const,
      path: '/api/finance',
      responses: {
        200: z.array(z.custom<typeof financeRequests.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/finance',
      input: insertFinanceRequestSchema,
      responses: {
        201: z.custom<typeof financeRequests.$inferSelect>(),
      },
    },
    updateStatus: {
      method: 'PATCH' as const,
      path: '/api/finance/:id/status',
      input: z.object({ status: z.string() }),
      responses: {
        200: z.custom<typeof financeRequests.$inferSelect>(),
      },
    },
  },
  notices: {
    list: {
      method: 'GET' as const,
      path: '/api/notices',
      responses: {
        200: z.array(z.custom<typeof notices.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/notices',
      input: insertNoticeSchema,
      responses: {
        201: z.custom<typeof notices.$inferSelect>(),
      },
    },
  },
  marks: {
    list: {
      method: 'GET' as const,
      path: '/api/marks',
      input: z.object({ studentId: z.string().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof studentMarks.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/marks',
      input: insertStudentMarksSchema,
      responses: {
        201: z.custom<typeof studentMarks.$inferSelect>(),
      },
    },
  },
  stats: {
    get: {
      method: 'GET' as const,
      path: '/api/stats',
      responses: {
        200: z.any(), // Flexible stats object
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
