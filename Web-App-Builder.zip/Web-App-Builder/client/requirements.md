## Packages
(none needed)

## Notes
- Using standard shadcn/ui components assumed to be present in `client/src/components/ui/` based on file list.
- Recharts, Framer Motion, and Date-fns are already installed.
- Authentication assumes cookie-based sessions with `credentials: "include"`.
