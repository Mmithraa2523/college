import { Switch, Route, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import Login from "@/pages/Login";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

// Page Imports
import AdminDashboard from "@/pages/admin/AdminDashboard";
import ManageDepartments from "@/pages/admin/ManageDepartments";
import HODDashboard from "@/pages/hod/HODDashboard";
import TimetableManager from "@/pages/hod/TimetableManager";
import StaffDashboard from "@/pages/staff/StaffDashboard";
import OfficeDashboard from "@/pages/office/OfficeDashboard";

function PrivateRoute({ component: Component, allowedRoles }: { component: React.ComponentType, allowedRoles: string[] }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return <div className="h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  if (!user) {
    // Return null to avoid rendering children while redirecting
    // However, setLocation updates state which might cause a re-render
    // It is better to handle redirection in a useEffect or render a Redirect component if wouter has one (it doesn't out of the box like react-router)
    // But since this is inside the render function, let's just use the Redirect component pattern if possible or return null after calling setLocation
    setTimeout(() => setLocation("/"), 0); 
    return null;
  }

  if (!allowedRoles.includes(user.role)) {
    return <div className="h-screen flex items-center justify-center text-xl font-bold text-destructive">Unauthorized Access</div>;
  }

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Switch>
          <Route path="/" component={Login} />
          
          {/* Admin Routes */}
          <Route path="/admin">
            <PrivateRoute component={AdminDashboard} allowedRoles={['admin']} />
          </Route>
          <Route path="/admin/departments">
            <PrivateRoute component={ManageDepartments} allowedRoles={['admin']} />
          </Route>
          <Route path="/admin/users">
            {/* Reuse Admin Dashboard for simplicity in this generated version */}
            <PrivateRoute component={AdminDashboard} allowedRoles={['admin']} />
          </Route>

          {/* HOD Routes */}
          <Route path="/hod">
            <PrivateRoute component={HODDashboard} allowedRoles={['hod']} />
          </Route>
          <Route path="/hod/timetable">
            <PrivateRoute component={TimetableManager} allowedRoles={['hod']} />
          </Route>
           <Route path="/hod/staff">
            <PrivateRoute component={HODDashboard} allowedRoles={['hod']} />
          </Route>

          {/* Staff Routes */}
          <Route path="/staff">
            <PrivateRoute component={StaffDashboard} allowedRoles={['staff']} />
          </Route>
          <Route path="/staff/leaves">
             <PrivateRoute component={StaffDashboard} allowedRoles={['staff']} />
          </Route>
          <Route path="/staff/marks">
             <PrivateRoute component={StaffDashboard} allowedRoles={['staff']} />
          </Route>
           <Route path="/staff/finance">
             <PrivateRoute component={StaffDashboard} allowedRoles={['staff']} />
          </Route>

          {/* Office Routes */}
          <Route path="/office">
            <PrivateRoute component={OfficeDashboard} allowedRoles={['office_admin']} />
          </Route>
           <Route path="/office/finance">
            <PrivateRoute component={OfficeDashboard} allowedRoles={['office_admin']} />
          </Route>

          {/* Principal Routes */}
          <Route path="/principal">
            {/* Reusing Admin Dashboard layout for Principal for now */}
            <PrivateRoute component={AdminDashboard} allowedRoles={['principal']} />
          </Route>

          <Route component={NotFound} />
        </Switch>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
