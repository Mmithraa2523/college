import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { useNotices } from "@/hooks/use-data";
import { Bell, Calendar } from "lucide-react";
import { format } from "date-fns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

export function NoticeBoard() {
  const { data: notices, isLoading } = useNotices();

  return (
    <Card className="h-full shadow-md border-l-4 border-l-secondary">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-secondary" />
            Notice Board
          </CardTitle>
          <Badge variant="outline" className="bg-secondary/10 text-secondary-foreground border-0">
            {notices?.length || 0} New
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">Loading notices...</div>
          ) : notices && notices.length > 0 ? (
            <div className="space-y-4">
              {notices.map((notice) => (
                <div key={notice.id} className="p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-secondary/50 transition-colors">
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-semibold text-sm text-primary">{notice.title}</h4>
                    <span className="text-[10px] text-muted-foreground bg-white px-1.5 py-0.5 rounded border flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {notice.createdAt ? format(new Date(notice.createdAt), "MMM d") : ""}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-3">{notice.content}</p>
                  <div className="mt-2 flex gap-2">
                    <Badge variant="secondary" className="text-[10px] h-5 px-1.5 font-normal">
                      {notice.type}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground text-sm">
              No recent notices.
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
