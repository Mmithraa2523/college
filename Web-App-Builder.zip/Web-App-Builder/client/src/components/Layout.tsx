import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  LayoutDashboard, Users, Building2, Calendar, 
  FileText, Wallet, GraduationCap, LogOut, Menu, X, Bell 
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const roleNavItems = {
  admin: [
    { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
    { label: "Departments", href: "/admin/departments", icon: Building2 },
    { label: "Users", href: "/admin/users", icon: Users },
  ],
  hod: [
    { label: "Dashboard", href: "/hod", icon: LayoutDashboard },
    { label: "Timetable", href: "/hod/timetable", icon: Calendar },
    { label: "Staff", href: "/hod/staff", icon: Users },
  ],
  staff: [
    { label: "Dashboard", href: "/staff", icon: LayoutDashboard },
    { label: "Leaves", href: "/staff/leaves", icon: FileText },
    { label: "Marks", href: "/staff/marks", icon: GraduationCap },
    { label: "Finance", href: "/staff/finance", icon: Wallet },
  ],
  office_admin: [
    { label: "Dashboard", href: "/office", icon: LayoutDashboard },
    { label: "Finance Requests", href: "/office/finance", icon: Wallet },
  ],
  principal: [
    { label: "Dashboard", href: "/principal", icon: LayoutDashboard },
    { label: "Notices", href: "/principal/notices", icon: Bell },
  ]
};

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  if (!user) return <>{children}</>;

  const navItems = roleNavItems[user.role as keyof typeof roleNavItems] || [];

  const NavContent = () => (
    <div className="flex flex-col h-full bg-slate-900 text-slate-50">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded bg-secondary flex items-center justify-center text-secondary-foreground font-bold font-display text-xl">
            SC
          </div>
          <div>
            <h1 className="font-display font-bold text-lg leading-tight">Smart College</h1>
            <p className="text-xs text-slate-400">Management Portal</p>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} className={`
              flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200
              ${isActive 
                ? "bg-secondary text-secondary-foreground font-semibold shadow-md" 
                : "text-slate-300 hover:bg-white/10 hover:text-white"}
            `}>
              <Icon className="w-5 h-5" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 mb-4 px-2">
          <Avatar className="h-9 w-9 border border-slate-600">
            <AvatarFallback className="bg-primary-foreground text-primary font-bold">
              {user.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium truncate">{user.name}</p>
            <p className="text-xs text-slate-400 capitalize">{user.role}</p>
          </div>
        </div>
        <Button 
          variant="destructive" 
          className="w-full justify-start gap-2" 
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4" />
          Logout
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 shrink-0 fixed inset-y-0 left-0 z-50 shadow-xl">
        <NavContent />
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 min-h-screen flex flex-col">
        {/* Mobile Header */}
        <header className="md:hidden bg-white border-b p-4 flex items-center justify-between sticky top-0 z-40">
           <div className="flex items-center gap-2">
             <div className="h-8 w-8 rounded bg-primary flex items-center justify-center text-primary-foreground font-bold">SC</div>
             <span className="font-display font-bold text-primary">Smart College</span>
           </div>
           <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
             <SheetTrigger asChild>
               <Button variant="ghost" size="icon"><Menu className="w-6 h-6" /></Button>
             </SheetTrigger>
             <SheetContent side="left" className="p-0 border-r-0 w-72">
               <NavContent />
             </SheetContent>
           </Sheet>
        </header>

        <div className="flex-1 p-4 md:p-8 max-w-7xl mx-auto w-full animate-in">
          {children}
        </div>
      </main>
    </div>
  );
}
