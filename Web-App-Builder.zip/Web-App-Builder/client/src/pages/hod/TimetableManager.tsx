import { useTimetables, useGenerateTimetable, usePublishTimetable } from "@/hooks/use-data";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Loader2, Upload, Calendar } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";

export default function TimetableManager() {
  const { user } = useAuth();
  const { data: timetables, isLoading } = useTimetables();
  const generate = useGenerateTimetable();
  const publish = usePublishTimetable();
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<'automatic' | 'assisted'>('automatic');

  // Simple mock display for generated JSON
  const renderTimetable = (data: any) => (
    <div className="grid grid-cols-6 gap-2 text-xs">
      <div className="font-bold bg-slate-100 p-2 rounded">Time</div>
      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(d => (
        <div key={d} className="font-bold bg-slate-100 p-2 rounded text-center">{d}</div>
      ))}
      {/* Mock Rows */}
      {['9:00', '10:00', '11:00', '12:00'].map(time => (
        <>
          <div key={time} className="p-2 font-medium">{time}</div>
          {[1,2,3,4,5].map(i => (
             <div key={`${time}-${i}`} className="p-2 border rounded bg-white text-center text-muted-foreground">
               -
             </div>
          ))}
        </>
      ))}
    </div>
  );

  const handleGenerate = () => {
    if (!user?.departmentId) return;
    generate.mutate({ 
      departmentId: user.departmentId, 
      mode,
      constraints: mode === 'assisted' ? { maxHoursPerDay: 4 } : undefined 
    }, {
      onSuccess: () => setIsOpen(false)
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold font-display">Timetable Management</h1>
          <p className="text-muted-foreground">AI-Powered Schedule Generation</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 bg-gradient-to-r from-primary to-blue-700 shadow-lg hover:shadow-xl transition-all">
              <Sparkles className="w-4 h-4" /> Generate New Timetable
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>AI Generation Settings</DialogTitle>
              <DialogDescription>Choose how you want the AI to create the schedule.</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="automatic" onValueChange={(v) => setMode(v as any)}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="automatic">Automatic</TabsTrigger>
                <TabsTrigger value="assisted">Assisted</TabsTrigger>
              </TabsList>
              <TabsContent value="automatic" className="space-y-4 py-4">
                <div className="p-4 bg-slate-50 rounded-lg text-sm text-slate-600">
                  Fully automated generation based on subject availability and standard constraints. Best for quick drafts.
                </div>
              </TabsContent>
              <TabsContent value="assisted" className="space-y-4 py-4">
                <div className="space-y-2">
                   <label className="text-sm font-medium">Constraints Priority</label>
                   <Select defaultValue="balanced">
                     <SelectTrigger><SelectValue /></SelectTrigger>
                     <SelectContent>
                       <SelectItem value="balanced">Balanced Workload</SelectItem>
                       <SelectItem value="compact">Compact Schedule</SelectItem>
                     </SelectContent>
                   </Select>
                </div>
                <div className="p-4 bg-yellow-50 text-yellow-800 rounded-lg text-xs">
                  Assisted mode allows manual tweaks before finalization.
                </div>
              </TabsContent>
            </Tabs>
            <Button onClick={handleGenerate} disabled={generate.isPending} className="w-full">
              {generate.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</> : "Start Generation"}
            </Button>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6">
        {isLoading ? (
          <div>Loading...</div>
        ) : timetables?.map((timetable) => (
           <Card key={timetable.id} className="border-l-4 border-l-primary">
             <CardHeader className="flex flex-row items-center justify-between pb-2">
               <div>
                 <CardTitle className="text-lg">Timetable #{timetable.id}</CardTitle>
                 <CardDescription>Status: <span className="uppercase font-bold text-xs">{timetable.status}</span></CardDescription>
               </div>
               {timetable.status === 'draft' && (
                 <Button size="sm" variant="secondary" onClick={() => publish.mutate(timetable.id)} disabled={publish.isPending}>
                   <Upload className="w-4 h-4 mr-2" /> Publish
                 </Button>
               )}
             </CardHeader>
             <CardContent>
               <div className="bg-slate-50 p-4 rounded-lg border">
                 {/* Placeholder visualization */}
                 {renderTimetable(timetable.data)}
               </div>
             </CardContent>
           </Card>
        ))}
        {timetables?.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed">
            <Calendar className="w-12 h-12 mx-auto text-slate-300 mb-4" />
            <h3 className="text-lg font-medium">No Timetables Found</h3>
            <p className="text-slate-500">Generate your first timetable to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
}
