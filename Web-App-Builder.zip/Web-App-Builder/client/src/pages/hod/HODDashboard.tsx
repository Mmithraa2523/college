import { useStats, useLeaves, useUpdateLeaveStatus } from "@/hooks/use-data";
import { StatCard } from "@/components/StatCard";
import { NoticeBoard } from "@/components/NoticeBoard";
import { Users, Calendar, FileText, CheckCircle, XCircle } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function HODDashboard() {
  const { data: stats } = useStats();
  const { data: leaves } = useLeaves();
  const updateStatus = useUpdateLeaveStatus();

  // Filter pending leaves for this HOD's department (Mock logic assuming API handles filtering for now)
  const pendingLeaves = leaves?.filter(l => l.status === 'pending_hod') || [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">HOD Dashboard</h1>
          <p className="text-slate-500 mt-1">Department management overview.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Department Staff" value={stats?.staffCount || 0} icon={Users} />
        <StatCard title="Active Timetables" value={1} icon={Calendar} />
        <StatCard title="Pending Leaves" value={pendingLeaves.length} icon={FileText} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border shadow-sm">
            <CardHeader>
              <CardTitle>Pending Leave Requests</CardTitle>
            </CardHeader>
            <CardContent>
              {pendingLeaves.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">No pending requests</div>
              ) : (
                <div className="space-y-4">
                  {pendingLeaves.map(leave => (
                    <div key={leave.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border">
                      <div>
                        <p className="font-semibold text-sm">Staff ID: {leave.staffId}</p>
                        <p className="text-xs text-muted-foreground">{leave.type} • {leave.reason}</p>
                        <p className="text-xs font-medium mt-1">{leave.startDate} to {leave.endDate}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="text-green-600 hover:text-green-700 hover:bg-green-50"
                           onClick={() => updateStatus.mutate({ id: leave.id, status: 'approved' })}>
                          <CheckCircle className="w-4 h-4 mr-1" /> Approve
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50"
                           onClick={() => updateStatus.mutate({ id: leave.id, status: 'rejected' })}>
                          <XCircle className="w-4 h-4 mr-1" /> Reject
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        <div>
          <NoticeBoard />
        </div>
      </div>
    </div>
  );
}
