import { useFinanceRequests, useUpdateFinanceStatus } from "@/hooks/use-data";
import { StatCard } from "@/components/StatCard";
import { Wallet, CheckCircle, XCircle, CreditCard } from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function OfficeDashboard() {
  const { data: requests, isLoading } = useFinanceRequests();
  const updateStatus = useUpdateFinanceStatus();

  const pending = requests?.filter(r => r.status === 'pending') || [];
  const approved = requests?.filter(r => r.status === 'approved') || [];

  return (
    <div className="space-y-6">
       <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">Office Administration</h1>
        <p className="text-slate-500">Finance & Administrative Tasks</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="Pending Bills" value={pending.length} icon={Wallet} />
        <StatCard title="Ready for Payment" value={approved.length} icon={CreditCard} />
        <StatCard title="Total Processed" value={requests?.length || 0} icon={CheckCircle} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Finance Requests Queue</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
             {isLoading ? <div>Loading...</div> : pending.length === 0 ? (
               <p className="text-muted-foreground">No pending requests.</p>
             ) : (
               pending.map(req => (
                 <div key={req.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg bg-slate-50 gap-4">
                   <div>
                     <div className="flex items-center gap-2">
                       <span className="font-bold text-lg">${req.amount}</span>
                       <Badge variant="outline" className="uppercase">{req.type}</Badge>
                     </div>
                     <p className="text-sm text-slate-600 mt-1">{req.description}</p>
                     <p className="text-xs text-slate-400 mt-2">Requested by User #{req.requesterId}</p>
                   </div>
                   <div className="flex gap-2">
                     <Button size="sm" onClick={() => updateStatus.mutate({ id: req.id, status: 'approved' })}>
                       Approve
                     </Button>
                     <Button size="sm" variant="destructive" onClick={() => updateStatus.mutate({ id: req.id, status: 'rejected' })}>
                       Reject
                     </Button>
                   </div>
                 </div>
               ))
             )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
