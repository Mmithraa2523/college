import { useAuth } from "@/hooks/use-auth";
import { useStats } from "@/hooks/use-data";
import { StatCard } from "@/components/StatCard";
import { NoticeBoard } from "@/components/NoticeBoard";
import { Calendar, FileText, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function StaffDashboard() {
  const { user } = useAuth();
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold text-slate-900">Welcome, {user?.name}</h1>
        <p className="text-slate-500">Staff Portal Overview</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="My Classes Today" value={4} icon={Calendar} />
        <StatCard title="Leave Balance" value="12 Days" icon={FileText} />
        <StatCard title="Pending Marks" value={2} icon={GraduationCap} trend="down" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid gap-6">
           <div className="bg-white p-6 rounded-xl border shadow-sm">
             <h3 className="font-bold text-lg mb-4">Quick Actions</h3>
             <div className="flex gap-4 flex-wrap">
               <Link href="/staff/leaves">
                 <Button variant="outline" className="h-24 w-32 flex-col gap-2 hover:border-primary hover:bg-primary/5">
                   <FileText className="w-6 h-6 text-primary" /> Apply Leave
                 </Button>
               </Link>
               <Link href="/staff/marks">
                 <Button variant="outline" className="h-24 w-32 flex-col gap-2 hover:border-primary hover:bg-primary/5">
                   <GraduationCap className="w-6 h-6 text-primary" /> Enter Marks
                 </Button>
               </Link>
             </div>
           </div>
           
           <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h3 className="font-bold text-lg mb-4">Upcoming Schedule</h3>
              <div className="text-sm text-slate-500 text-center py-8 bg-slate-50 rounded-lg">
                No classes scheduled for the rest of the day.
              </div>
           </div>
        </div>
        <div>
          <NoticeBoard />
        </div>
      </div>
    </div>
  );
}
