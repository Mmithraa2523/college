import { useStats } from "@/hooks/use-data";
import { StatCard } from "@/components/StatCard";
import { NoticeBoard } from "@/components/NoticeBoard";
import { Users, Building2, UserCheck, ShieldCheck } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats } = useStats();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">Admin Overview</h1>
          <p className="text-slate-500 mt-1">System monitoring and management console.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Departments" value={stats?.departmentsCount || 0} icon={Building2} />
        <StatCard title="Total Staff" value={stats?.staffCount || 0} icon={Users} />
        <StatCard title="Total Students" value={stats?.studentCount || 0} icon={UserCheck} />
        <StatCard title="System Logs" value={stats?.logsCount || 0} icon={ShieldCheck} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
           {/* Add charts or tables here later */}
           <div className="bg-white p-6 rounded-xl border shadow-sm h-64 flex items-center justify-center text-muted-foreground">
             Activity Chart Placeholder
           </div>
        </div>
        <div>
          <NoticeBoard />
        </div>
      </div>
    </div>
  );
}
