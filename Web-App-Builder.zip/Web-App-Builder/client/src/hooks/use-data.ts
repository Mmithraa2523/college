import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import { 
  type InsertDepartment, type Department,
  type InsertUser, type User,
  type InsertTimetable, type Timetable,
  type InsertLeave, type Leave,
  type InsertFinanceRequest, type FinanceRequest,
  type InsertNotice, type Notice,
  type InsertStudentMark, type StudentMark
} from "@shared/schema";

// Helper for generic mutations
function useGenericMutation<TInput, TOutput>(
  url: string, 
  method: string, 
  queryKeyToInvalidate: string[],
  successMessage: string
) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: TInput) => {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).message || "Request failed");
      return await res.json() as TOutput;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeyToInvalidate });
      toast({ title: "Success", description: successMessage });
    },
    onError: (err: Error) => {
      toast({ variant: "destructive", title: "Error", description: err.message });
    },
  });
}

// === DEPARTMENTS ===
export function useDepartments() {
  return useQuery({
    queryKey: [api.departments.list.path],
    queryFn: async () => {
      const res = await fetch(api.departments.list.path);
      return await res.json() as Department[];
    }
  });
}

export function useCreateDepartment() {
  return useGenericMutation<InsertDepartment, Department>(
    api.departments.create.path, 
    api.departments.create.method, 
    [api.departments.list.path], 
    "Department created successfully"
  );
}

// === USERS ===
export function useUsers(role?: string) {
  return useQuery({
    queryKey: [api.users.list.path, role],
    queryFn: async () => {
      const url = buildUrl(api.users.list.path) + (role ? `?role=${role}` : "");
      const res = await fetch(url);
      return await res.json() as User[];
    }
  });
}

export function useCreateUser() {
  return useGenericMutation<InsertUser, User>(
    api.users.create.path,
    api.users.create.method,
    [api.users.list.path],
    "User created successfully"
  );
}

// === TIMETABLES ===
export function useTimetables() {
  return useQuery({
    queryKey: [api.timetables.list.path],
    queryFn: async () => {
      const res = await fetch(api.timetables.list.path);
      return await res.json() as Timetable[];
    }
  });
}

export function useGenerateTimetable() {
  return useGenericMutation<{ departmentId: number, mode: 'automatic' | 'assisted', constraints?: any }, Timetable>(
    api.timetables.generate.path,
    api.timetables.generate.method,
    [api.timetables.list.path],
    "Timetable generated successfully"
  );
}

export function usePublishTimetable() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.timetables.publish.path, { id });
      const res = await fetch(url, { method: api.timetables.publish.method });
      if (!res.ok) throw new Error("Failed to publish");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.timetables.list.path] });
      toast({ title: "Published", description: "Timetable is now live." });
    }
  });
}

// === LEAVES ===
export function useLeaves() {
  return useQuery({
    queryKey: [api.leaves.list.path],
    queryFn: async () => {
      const res = await fetch(api.leaves.list.path);
      return await res.json() as Leave[];
    }
  });
}

export function useCreateLeave() {
  return useGenericMutation<InsertLeave, Leave>(
    api.leaves.create.path,
    api.leaves.create.method,
    [api.leaves.list.path],
    "Leave request submitted"
  );
}

export function useUpdateLeaveStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, status, rejectionReason }: { id: number, status: string, rejectionReason?: string }) => {
      const url = buildUrl(api.leaves.updateStatus.path, { id });
      const res = await fetch(url, { 
        method: api.leaves.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, rejectionReason })
      });
      if (!res.ok) throw new Error("Failed to update status");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.leaves.list.path] });
      toast({ title: "Updated", description: "Leave status updated." });
    }
  });
}

// === FINANCE ===
export function useFinanceRequests() {
  return useQuery({
    queryKey: [api.finance.list.path],
    queryFn: async () => {
      const res = await fetch(api.finance.list.path);
      return await res.json() as FinanceRequest[];
    }
  });
}

export function useCreateFinanceRequest() {
  return useGenericMutation<InsertFinanceRequest, FinanceRequest>(
    api.finance.create.path,
    api.finance.create.method,
    [api.finance.list.path],
    "Finance request submitted"
  );
}

export function useUpdateFinanceStatus() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const url = buildUrl(api.finance.updateStatus.path, { id });
      const res = await fetch(url, { 
        method: api.finance.updateStatus.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      if (!res.ok) throw new Error("Failed to update status");
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.finance.list.path] });
      toast({ title: "Updated", description: "Request status updated." });
    }
  });
}

// === NOTICES ===
export function useNotices() {
  return useQuery({
    queryKey: [api.notices.list.path],
    queryFn: async () => {
      const res = await fetch(api.notices.list.path);
      return await res.json() as Notice[];
    }
  });
}

export function useCreateNotice() {
  return useGenericMutation<InsertNotice, Notice>(
    api.notices.create.path,
    api.notices.create.method,
    [api.notices.list.path],
    "Notice published successfully"
  );
}

// === STATS ===
export function useStats() {
  return useQuery({
    queryKey: [api.stats.get.path],
    queryFn: async () => {
      const res = await fetch(api.stats.get.path);
      return await res.json();
    }
  });
}
